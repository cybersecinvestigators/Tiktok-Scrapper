//Submit button
// *****************************************************************

document.onload = document.getElementById('submit').addEventListener('click', () => {
    value = document.getElementById('uid').value;
    value = value.replace(/\D/g, "");
    if(value.length > 1){
        localStorage.setItem('tbuid',value);
        localStorage.setItem('status', 'running');
        localStorage.setItem('pgnum', '10');
        window.close();
    }
    else{
        document.getElementById('uid').setAttribute('placeholder','Enter a valid UserId');
        
    }
    
}); 

// ********************************************************************

document.addEventListener("DOMContentLoaded", function(event) {
  if(localStorage.getItem('tbuid')){
    document.getElementById('uid').value = localStorage.getItem('tbuid')
    document.getElementById('uid').setAttribute('disabled','true');
    document.getElementById('submit').style.visibility = 'hidden';
    document.getElementById('logout').setAttribute('style', 'visibility:visible !important');
  }
  
  if(localStorage.getItem('status') == 'running'){
    document.getElementById('pause').setAttribute('style', 'visibility:visible !important');
  }

  else if(localStorage.getItem('status') == 'pause'){
    document.getElementById('continue').setAttribute('style', 'visibility:visible !important');
  } 
});


//buttons

document.onload = document.getElementById('logout').addEventListener('click', () => {
    localStorage.setItem('tbuid','');
    localStorage.setItem('status', 'stop');
    window.close();
});

document.onload = document.getElementById('pause').addEventListener('click', () => {
  localStorage.setItem('status', 'pause');
  window.close();
});

document.onload = document.getElementById('continue').addEventListener('click', () => {
  localStorage.setItem('status', 'running');
  window.close();
});
