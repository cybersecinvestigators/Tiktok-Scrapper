chrome.runtime.connect({ name: "popup" });
chrome.tabs.query({active: true, lastFocusedWindow: true}, activetabs => {
    let url = activetabs[0].url;

    if( url.includes("tiktok.com/login")){
        chrome.tabs.executeScript(activetabs[0].tabID, {"code":"alert('Please Login to Continue')"});
            window.close();
    }

    else if( url.includes("tiktok.com")) {
        chrome.tabs.executeScript(activetabs[0].tabID, {"code":"if(!(document.getElementsByClassName('login-button').length == 0)){alert('Please Login to Continue')}" });
    }

    else{
        chrome.tabs.create({url: "https://www.tiktok.com/login"});
    }
});
