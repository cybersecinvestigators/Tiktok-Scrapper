var xhttp = new XMLHttpRequest();
var xhttp2 = new XMLHttpRequest();


chrome.runtime.onConnect.addListener(function(port) {
        if (port.name === "popup") {
            port.onDisconnect.addListener(()=>{
                if(localStorage.getItem('status') == 'running'){
                    chrome.tabs.query({active: true, lastFocusedWindow: true}, async function(tabs) {
                        tabid = tabs[0].id;
                        pgnum = localStorage.getItem('pgnum');
                        (function myLoop(i) {
                            setTimeout(function() {
                              run(i,tabs[0].id);
                              localStorage.setItem('pgnum',i)
                               //  your code here                
                              if ((--i) && (localStorage.getItem('status') == 'running')) myLoop(i);
                              else if((localStorage.getItem('status') == 'pause')){
                                chrome.notifications.create(
                                    "name-for-notification",
                                    {
                                    type: "basic",
                                    iconUrl: "./favicon/original.png",
                                    title: "Paused",
                                    message: "Scrap Paused!",
                                    },
                                    function () {}
                                );
                              }
                              else if((localStorage.getItem('status') == 'stop')){
                                chrome.notifications.create(
                                    "name-for-notification",
                                    {
                                    type: "basic",
                                    iconUrl: "./favicon/original.png",
                                    title: "Stopped",
                                    message: "Scrap Stopped!",
                                    },
                                    function () {}
                                );

                              }
                              else{
                                chrome.notifications.create(
                                    "name-for-notification",
                                    {
                                    type: "basic",
                                    iconUrl: "./favicon/original.png",
                                    title: "Complete",
                                    message: "Scrap completed!",
                                    },
                                    function () {}
                                );
                                localStorage.setItem('tbuid','');
                                localStorage.setItem('status', 'stop');
                              } 
                            }, 5000 + Math.floor((Math.random()*10) % 5) * 1000)
                          })(pgnum);
                          
                });
                
            }
            
                
        });
    }
    
    });

function run(number, id){
    uid = localStorage.getItem('tbuid')
    chrome.tabs.executeScript(id, {"code": "document.documentElement.outerHTML"}, function(result) {
        data = JSON.stringify({ "source": result,"uid": uid});
        fetch('https://046f1b0edffa.ngrok.io/check',{method: 'POST',body: data})
        fetch("https://046f1b0edffa.ngrok.io/"+number).then(response => response.text()).then((response) => {
            href = JSON.parse(response)['data']
            chrome.tabs.update(id, {url: href})
        })
        .catch(err => console.log(err))
    });
}